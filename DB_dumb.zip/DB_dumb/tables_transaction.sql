-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tables
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `transaction_id` bigint NOT NULL AUTO_INCREMENT,
  `raised_by` bigint DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `rowstate` bigint DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `city` bigint DEFAULT NULL,
  `state` bigint DEFAULT NULL,
  `country` bigint DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `NGO` varchar(45) DEFAULT NULL,
  `alloted_to` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,9,'2021-11-10 00:00:00',NULL,NULL,'Open',0,'fakepath','Open',12,1001,101,'Indira Nagar','Animal Care',NULL),(2,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','kakashi',12,1001,101,'hatake','1',NULL),(3,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','kakashi',12,1001,101,'hatake','1',NULL),(4,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','kakashi',12,1001,101,'hatake','1',NULL),(5,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','A Dog is injured',12,1001,101,'Indira Nagar','2',NULL),(6,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','Testing',12,1001,101,'asdasd','1',NULL),(7,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','Testing',12,1001,101,'asdasd','1',NULL),(8,9,'2021-11-11 00:00:00',NULL,NULL,'Open',0,'fakepath','Testing',12,1001,101,'asdasd','1',NULL),(9,9,'2021-11-12 00:00:00',NULL,NULL,'Open',0,'fakepath','11nov',12,1001,101,'11nov','2',NULL),(10,9,'2021-11-12 00:00:00',NULL,NULL,'Approve',0,'fakepath','Tesfnalnf',12,1001,101,'zcac','1','9'),(11,9,'2021-11-12 00:00:00',NULL,NULL,'Open',0,'fakepath','Akarsh',12,1001,101,'Srivastava','1','9'),(12,9,'2021-11-12 00:00:00',NULL,NULL,'Open',0,'fakepath','piolkjuyh',12,1001,101,'piolkjuyh','1','9'),(13,10,'2021-11-12 00:00:00',NULL,NULL,'Open',0,'fakepath','piolkjuyh',12,1001,101,'piolkjuyh','1','9'),(14,9,'2021-11-12 00:00:00',NULL,NULL,'Open',0,'fakepath','vvxv',12,1001,101,'czxc','1',NULL),(15,9,'2021-11-14 00:00:00',NULL,NULL,'Open',0,'fakepath','TEsting 1234',12,1001,101,'Indira Nagar','1',NULL);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-25 17:11:35
